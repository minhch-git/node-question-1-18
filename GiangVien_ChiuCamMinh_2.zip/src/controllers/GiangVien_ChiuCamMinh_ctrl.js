import createError from 'http-errors'
import pick from '../utils/pick'
import giangVienService from '../services/GiangVien_ChiuCamMinh_service'

class GiangVienCtrl {
  /**
   * @GET api/v1/giangViens
   * @access public
   */
  async getGiangViens(req, res) {
    const filter = pick(req.query, ['giangVien', 'hangXe', 'soChoNgoi'])
    const options = pick(req.query, ['sortBy', 'limit', 'page'])
    const result = await giangVienService.query(filter, options)
    res.send(result)
  }

  /**
   * @GET api/v1/giangViens/:id
   * @access public
   */
  async getGiangVien(req, res) {
    const giangVien = await giangVienService.findById(req.params.id)
    if (!giangVien) {
      throw createError.NotFound('GiangVien not found')
    }
    res.send(giangVien)
  }

  /**
   * @POST api/v1/giangViens/
   * @access private
   */
  async createGiangVien(req, res) {
    const giangVien = await giangVienService.create(req.body)
    res.status(201).send(giangVien)
  }

  /**
   * @PATCH api/v1/giangViens/:id
   * @access private
   */
  async updateGiangVien(req, res) {
    const giangVien = await giangVienService.updateById(req.params.id, req.body)
    res.send(giangVien)
  }

  /**
   * @DELETE api/v1/giangViens/:id
   * @access private
   */
  async deleteGiangVien(req, res) {
    await giangVienService.deleteById(req.params.id)
    res.status(200).json({ success: true })
  }
}

export default new GiangVienCtrl()
