import createError from 'http-errors'
import pick from '../utils/pick'
import dangKyCungCapService from '../services/dang-ky-cung-cap.service'

class DangKyCungCapCtrl {
  /**
   * @GET api/v1/dangKyCungCaps
   * @access public
   */
  async getDangKyCungCaps(req, res) {
    const filter = pick(req.query, ['dongXe', 'ngayBatDauCungCap'])
    const options = pick(req.query, ['sortBy', 'limit', 'page'])
    options.populate = 'maNhaCungCap,maLoaiDichVu,dongXe,maMucPhi'
    const result = await dangKyCungCapService.query(filter, options)
    res.send(result)
  }

  /**
   * @GET api/v1/dangKyCungCaps/:id
   * @access public
   */
  async getDangKyCungCap(req, res) {
    const dangKyCungCap = await dangKyCungCapService.findById(req.params.id)
    if (!dangKyCungCap) {
      throw createError.NotFound('DangKyCungCap not found')
    }
    res.send(dangKyCungCap)
  }

  /**
   * @POST api/v1/dangKyCungCaps/
   * @access private
   */
  async createDangKyCungCap(req, res) {
    const dangKyCungCap = await dangKyCungCapService.create(req.body)
    res.status(201).send(dangKyCungCap)
  }

  /**
   * @PATCH api/v1/dangKyCungCaps/:id
   * @access private
   */
  async updateDangKyCungCap(req, res) {
    const dangKyCungCap = await dangKyCungCapService.updateById(
      req.params.id,
      req.body
    )
    res.send(dangKyCungCap)
  }

  /**
   * @DELETE api/v1/dangKyCungCaps/:id
   * @access private
   */
  async deleteDangKyCungCap(req, res) {
    await dangKyCungCapService.deleteById(req.params.id)
    res.status(200).json({ success: true })
  }

  /**
   * @GET api/v1/dangKyCungCaps/nhaCungCap?dongXe|price=Toyota|15000|KIA|20000
   * @access public
   */
  async getNhaCungCapByDongXeAndDonGia(req, res) {
    let filter = [
      {
        hangXe: 'Toyota',
        dongGia: '15000',
      },
      {
        hangXe: 'Kia',
        dongGia: '20000',
      },
    ]

    let nhaCungCap = await dangKyCungCapService.getNhaCungCapByDongXe(filter)
    res.status(200).json({ success: true, data: nhaCungCap })
  }

  /**
   * @GET api/v1/dangKyCungCaps/nhaCungCap?dongXe|price=Toyota|15000|KIA|20000
   * @access public
   */
  async getCountNumberNhaCungCapDangKy(req, res) {
    let key = Object.keys(req.query.ngayBatDauCungCap)
    req.query.ngayBatDauCungCap[key] = new Date(
      +req.query.ngayBatDauCungCap[key]
    )
    const filter = pick(req.query, ['ngayBatDauCungCap'])
    let numberNhaCungCapDangKy =
      await dangKyCungCapService.countNumberNhaCungCapDangKy(filter)
    res.status(200).json({ success: true, data: numberNhaCungCapDangKy })
  }
  /**
   * @GET api/v1/dangKyCungCaps/nhaCungCap?dongXe|price=Toyota|15000|KIA|20000
   * @access public
   */
  async getNhaCungCapByDongXe(req, res) {
    let options = {
      $or: [
        { dongXe: req.query.dongXe.split('|')[0] },
        { dongXe: req.query.dongXe.split('|')[1] },
      ],
    }
    const result = await dangKyCungCapService
      .find(options)
      .populate('maNhaCungCap')
      .populate({ path: 'dongXe', select: 'dongXe' })
      .select('maNhaCungCap dongXe')
    res.status(200).json({ success: true, data: result })
  }
}

export default new DangKyCungCapCtrl()
