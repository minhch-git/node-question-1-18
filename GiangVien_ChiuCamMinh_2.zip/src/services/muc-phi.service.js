import createError from 'http-errors'
import MucPhi from '../models/MucPhi'

class MucPhiService {
  /**
   * Find mucPhi by id
   * @param {ObjectId} id
   * @returns {Promise<mucPhi>}
   */
  findById(id) {
    return MucPhi.findById(id)
  }

  /**
   * Find mucPhi by object
   * @param {ObjectId} object
   * @returns {Promise<mucPhi>}
   */
  findOne(filter) {
    return MucPhi.find()
  }
  /**
   * Get mucPhis by query(filter, options)
   * @param {Object} filter
   * @param {Object} options
   * @returns {Promise<mucPhis>}
   */
  async query(filter, options) {
    const mucPhis = await MucPhi.paginate(filter, options)
    return mucPhis
  }

  /**
   * Create mucPhi
   * @param {Object} body
   * @returns {Promise<mucPhi>}
   */
  async create(body) {
    return MucPhi.create(body)
  }

  /**
   * Update mucPhi by id
   * @param {ObjectId} id
   * @param {Object} body
   * @returns {Promise<mucPhi>}
   */
  async updateById(id, body) {
    const mucPhi = await this.findById(id)

    if (!mucPhi) {
      throw createError.NotFound()
    }

    Object.assign(mucPhi, body)
    await mucPhi.save()
    return mucPhi
  }

  /**
   * Delte mucPhi by id
   * @param {ObjectId} id
   * @returns {Promise<mucPhi>}
   */
  async deleteById(id) {
    const mucPhi = await this.findById(id)
    if (!mucPhi) {
      throw createError.NotFound('MucPhis not found')
    }
    const result = await mucPhi.remove()
    return result
  }
}

export default new MucPhiService()
