import createError from 'http-errors'
import GiangVien from '../models/GiangVien_ChiuCamMinh_2'

class GiangVienService {
  /**
   * Find giangVien by id
   * @param {ObjectId} id
   * @returns {Promise<giangVien>}
   */
  findById(id) {
    return GiangVien.findById(id)
  }

  /**
   * Find giangVien by object
   * @param {ObjectId} object
   * @returns {Promise<giangVien>}
   */
  findOne(filter) {
    return GiangVien.find(filter)
  }

  /**
   * Get giangViens by query(filter, options)
   * @param {Object} filter
   * @param {Object} options
   * @returns {Promise<giangViens>}
   */
  async query(filter, options) {
    const giangViens = await GiangVien.paginate(filter, options)
    return giangViens
  }

  /**
   * Create giangVien
   * @param {Object} body
   * @returns {Promise<giangVien>}
   */
  async create(body) {
    return GiangVien.create(body)
  }

  /**
   * Update giangVien by id
   * @param {ObjectId} id
   * @param {Object} body
   * @returns {Promise<giangVien>}
   */
  async updateById(id, body) {
    const giangVien = await GiangVien.findByIdAndUpdate(id, body, { new: true })
    return giangVien
  }

  /**
   * Delte giangVien by id
   * @param {ObjectId} id
   * @returns {Promise<giangVien>}
   */
  async deleteById(id) {
    const giangVien = await this.findById(id)
    if (!giangVien) {
      throw createError.NotFound('GiangViens not found')
    }
    const result = await giangVien.remove()
    return result
  }
}

export default new GiangVienService()
