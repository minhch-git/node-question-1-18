import createError from 'http-errors'
import DongXe from '../models/DongXe'

class DongXeService {
  /**
   * Find dongXe by id
   * @param {ObjectId} id
   * @returns {Promise<dongXe>}
   */
  findById(id) {
    return DongXe.findById(id)
  }

  /**
   * Find dongXe by id
   * @returns {Promise<dongXe>}
   */
  async getHangXe() {
    let result = await DongXe.aggregate([
      {
        $group: {
          _id: '$hangXe',
        },
      },
    ])
    return result
  }

  /**
   * Find dongXe by object
   * @param {ObjectId} object
   * @returns {Promise<dongXe>}
   */
  findOne(filter) {
    return DongXe.find(filter)
  }

  /**
   * Get dongXes by query(filter, options)
   * @param {Object} filter
   * @param {Object} options
   * @returns {Promise<dongXes>}
   */
  async query(filter, options) {
    const dongXes = await DongXe.paginate(filter, options)
    return dongXes
  }

  /**
   * Create dongXe
   * @param {Object} body
   * @returns {Promise<dongXe>}
   */
  async create(body) {
    return DongXe.create(body)
  }

  /**
   * Update dongXe by id
   * @param {ObjectId} id
   * @param {Object} body
   * @returns {Promise<dongXe>}
   */
  async updateById(id, body) {
    const dongXe = await this.findById(id)

    if (!dongXe) {
      throw createError.NotFound()
    }

    Object.assign(dongXe, body)
    await dongXe.save()
    return dongXe
  }

  /**
   * Delte dongXe by id
   * @param {ObjectId} id
   * @returns {Promise<dongXe>}
   */
  async deleteById(id) {
    const dongXe = await this.findById(id)
    if (!dongXe) {
      throw createError.NotFound('DongXes not found')
    }
    const result = await dongXe.remove()
    return result
  }
}

export default new DongXeService()
