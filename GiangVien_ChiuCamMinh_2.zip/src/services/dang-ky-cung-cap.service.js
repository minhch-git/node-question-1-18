import createError from 'http-errors'
import dongXeService from './dong-xe.service'
import mucPhiService from './muc-phi.service'
import DangKyCungCap from '../models/DangKyCungCap'
import nhaCungCapService from './nha-cung-cap.service'

class DangKyCungCapService {
  /**
   * Find dangKyCungCap
   * @param {object} options
   * @returns {Promise<dangKyCungCap>}
   */
  find(options) {
    return DangKyCungCap.find(options)
  }

  /**
   * Find dangKyCungCap by id
   * @param {ObjectId} id
   * @returns {Promise<dangKyCungCap>}
   */
  findById(id) {
    return DangKyCungCap.findById(id)
  }

  /**
   * Get dangKyCungCaps by query(filter, options)
   * @param {Object} filter
   * @param {Object} options
   * @returns {Promise<dangKyCungCaps>}
   */
  async query(filter, options) {
    const dangKyCungCaps = await DangKyCungCap.paginate(filter, options)
    return dangKyCungCaps
  }

  /**
   * Create dangKyCungCap
   * @param {Object} body
   * @returns {Promise<dangKyCungCap>}
   */
  async create(body) {
    return DangKyCungCap.create(body)
  }

  /**
   * Update dangKyCungCap by id
   * @param {ObjectId} id
   * @param {Object} body
   * @returns {Promise<dangKyCungCap>}
   */
  async updateById(id, body) {
    const dangKyCungCap = await this.findById(id)

    if (!dangKyCungCap) {
      throw createError.NotFound()
    }

    Object.assign(dangKyCungCap, body)
    await dangKyCungCap.save()
    return dangKyCungCap
  }

  /**
   * Delte dangKyCungCap by id
   * @param {ObjectId} id
   * @returns {Promise<dangKyCungCap>}
   */
  async deleteById(id) {
    const dangKyCungCap = await this.findById(id)
    if (!dangKyCungCap) {
      throw createError.NotFound('DangKyCungCaps not found')
    }
    const result = await dangKyCungCap.remove()
    return result
  }

  /**
   * Delte dangKyCungCap by filter
   * @param {array} filter
   * @returns {Promise<dangKyCungCap>}
   */
  async getNhaCungCapByDongXe(filter) {
    console.log(filter)
    const dongXes = await dongXeService
      .findOne({
        $or: [{ hangXe: 'Toyota' }, { hangXe: 'KIA' }],
      })
      .select('hangXe _id')

    const mucPhis = await mucPhiService
      .findOne({
        $or: [{ donGia: 15000 }, { donGia: 20000 }],
      })
      .select('donGia _id')

    const dongXeToyotas = dongXes.filter(dongXe => dongXe.hangXe === 'Toyota')
    const dongXeKIA = dongXes.filter(dongXe => dongXe.hangXe === 'KIA')

    const dongXeToyotaIds = dongXeToyotas.map(dongXe => dongXe._id)
    const dongXeKIAIds = dongXeKIA.map(dongXe => dongXe._id)

    const donGiaToyotas = mucPhis.filter(mucPhi => mucPhi.donGia === 15000)
    const donGiaKIA = mucPhis.filter(mucPhi => mucPhi.donGia === 20000)

    const donGiaToyotaIds = donGiaToyotas.map(donGia => donGia._id)
    const donGiaKIAIds = donGiaKIA.map(donGia => donGia._id)

    const options = {
      $or: [
        {
          dongXe: { $in: dongXeToyotaIds },
          maMucPhi: { $in: donGiaToyotaIds },
        },
        { dongXe: { $in: dongXeKIAIds }, maMucPhi: { $in: donGiaKIAIds } },
      ],
    }
    const result = await DangKyCungCap.find(options)
      .populate('maNhaCungCap')
      .populate({ path: 'dongXe', select: 'hangXe' })
      .populate({ path: 'maMucPhi', select: 'donGia' })
      .select('maNhaCungCap')
    return result
  }

  // Cau 7
  async countNumberNhaCungCapDangKy(filter) {
    const options = ''
    const { results } = await DangKyCungCap.paginate(filter, options)

    const objects = {}

    for (const dangKyCungCap of results) {
      const maNCC = dangKyCungCap.maNhaCungCap
      if (!objects[maNCC]) {
        objects[maNCC] = 1
      } else {
        objects[maNCC]++
      }
    }

    return objects
  }
}

export default new DangKyCungCapService()
