import mongoose, { Schema } from 'mongoose'
import { toJSON, paginate } from './plugins'

const loaiDichVuSchema = new Schema(
  {
    tenLoaiDichVu: {
      type: String,
      required: true,
      unique: true,
      trim: true,
    },
  },
  {
    timestamps: true,
  }
)

// add plugin that converts mongoose to json
loaiDichVuSchema.plugin(toJSON)
loaiDichVuSchema.plugin(paginate)

/**
 * @typedef LoaiDichVu
 */
const LoaiDichVu = mongoose.model('LoaiDichVu', loaiDichVuSchema)

export default LoaiDichVu
