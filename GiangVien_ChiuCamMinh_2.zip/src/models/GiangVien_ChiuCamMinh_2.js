import mongoose, { Schema } from 'mongoose'
import { toJSON, paginate } from './plugins'
const giangVienSchema = new Schema(
  {
    hoTenGV: {
      type: String,
      trim: true,
      required: true,
    },
    luong: {
      type: Number,
      required: true,
    },
    maKhoa: {
      type: Schema.Types.ObjectId,
      ref: 'Khoa',
    },
  },
  {
    timestamps: true,
  }
)

// add plugin that converts mongoose to json
giangVienSchema.plugin(toJSON)
giangVienSchema.plugin(paginate)

/**
 * @typedef DongXe
 */
const GiangVien = mongoose.model('GiangVien', giangVienSchema)

export default GiangVien
