import express from 'express'
import asyncHandler from '../../utils/asyncHandler'

import DangKyCungCap from '../../models/DangKyCungCap'
import NhaCungCap from '../../models/NhaCungCap'
import DongXe from '../../models/DongXe'
import LoaiDichVu from '../../models/LoaiDichVu'
import MucPhi from '../../models/MucPhi'

const router = express.Router()

router.route('/dang-ky-cung-cap').post(
  asyncHandler(async (req, res, next) => {
    await DangKyCungCap.deleteMany()
    let results = await DangKyCungCap.insertMany(req.body)
    return res.status(200).json({ results })
  })
)

router.route('/dong-xe').post(
  asyncHandler(async (req, res, next) => {
    await DongXe.deleteMany()
    let results = await DongXe.insertMany(req.body)
    return res.status(200).json({ results })
  })
)

router.route('/nha-cung-cap').post(
  asyncHandler(async (req, res, next) => {
    let results = await NhaCungCap.insertMany(req.body)
    return res.status(200).json({ results })
  })
)

router.route('/loai-dich-vu').post(
  asyncHandler(async (req, res, next) => {
    let results = await LoaiDichVu.insertMany(req.body)
    return res.status(200).json({ results })
  })
)

router.route('/muc-phi').post(
  asyncHandler(async (req, res, next) => {
    let results = await MucPhi.insertMany(req.body)
    return res.status(200).json({ results })
  })
)

export default router
