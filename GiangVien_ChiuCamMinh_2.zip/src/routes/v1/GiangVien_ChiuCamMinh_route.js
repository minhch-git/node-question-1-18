import express from 'express'
import validate from '../../middleware/validate'
import giangVienValidation from '../../validations/giang-vien.validation'
import GiangVienCtrl from '../../controllers/GiangVien_ChiuCamMinh_ctrl'
import asyncHandler from '../../utils/asyncHandler'

const router = express.Router()

router
  .route('/')
  .post(
    validate(giangVienValidation.createGiangVien),
    asyncHandler(GiangVienCtrl.createGiangVien)
  )
  .get(
    validate(giangVienValidation.getGiangViens),
    asyncHandler(GiangVienCtrl.getGiangViens)
  )

router
  .route('/:id')
  .get(
    validate(giangVienValidation.getGiangVien),
    asyncHandler(GiangVienCtrl.getGiangVien)
  )
  .patch(
    validate(giangVienValidation.updateGiangVien),
    asyncHandler(GiangVienCtrl.updateGiangVien)
  )
  .delete(
    validate(giangVienValidation.deleteGiangVien),
    asyncHandler(GiangVienCtrl.deleteGiangVien)
  )

export default router
