import { string, number } from 'yup'
import custom from './_custom.validation'

const createGiangVien = {
  hoTenGV: string().required(),
  luong: number().required(),
  maKhoa: custom.objectId.label('maKhoa').required(),
}

const getGiangViens = {
  hoTenGV: string(),
  luong: string(),
  maKhoa: custom.objectId.label('maKhoa'),
  sortBy: string(),
  limit: number().integer(),
  page: number().integer(),
}

const getGiangVien = {
  id: custom.objectId.label('id').required(),
}

const updateGiangVien = {
  hoTenGV: string(),
  luong: number(),
  maKhoa: custom.objectId.label('maKhoa'),
  id: custom.objectId.label('id'),
}

const deleteGiangVien = {
  id: custom.objectId.label('id'),
}

export default {
  createGiangVien,
  getGiangViens,
  getGiangVien,
  updateGiangVien,
  deleteGiangVien,
}
