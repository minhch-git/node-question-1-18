import { string, number, date, array, object } from 'yup'
import custom from './_custom.validation'

const insertManyDangKyCungCap = array().of(
  object().shape({
    maNhaCungCap: custom.objectId.required().label('maNhaCungCap'),
    maLoaiDichVu: custom.objectId.required().label('maLoaiDichVu'),
    dongXe: custom.objectId.required().label('dongXe'),
    maMucPhi: custom.objectId.required().label('maMucPhi'),
    ngayBatDauCungCap: date().required().default(Date.now()),
    ngayKetThucCungCap: date().required(),
    soLuongXeMayDangKy: number().integer().required(),
  })
)

const insertManyNhaCungCap = array().of(
  object().shape({
    tenNhaCungCap: string().required(),
    diaChi: string().required(),
    soDienThoai: string(),
    maSoThue: string(),
  })
)

const insertManyMucPhi = array().of(
  object().shape({
    moTa: string().required(),
    donGia: number().required(),
  })
)

const insertManyLoaiDichVu = array().of(
  object().shape({
    tenLoaiDichVu: string().required(),
  })
)
const insertManyDongXe = array().of(
  object().shape({
    hangXe: string().required(),
    soChoNgoi: number().required(),
  })
)
export default {
  insertManyDangKyCungCap,
  insertManyMucPhi,
  insertManyNhaCungCap,
  insertManyLoaiDichVu,
  insertManyDongXe,
}
